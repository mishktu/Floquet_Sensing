function PD_delta_kick_floquet_spectrum
clc
clear

%********************************************************************
vengkf = zeros(3,1);
vengki = zeros(3,1); vnk = zeros(3,1);
vmk = zeros(3,1); vnkf = zeros(3,1);

N=2000;  mrange=0:N/2-1;  krange=pi*(2*mrange+1)/N;
coupJ=1;

tau=0.2;
freq=1/tau;

%************************************************************************** 

  h0_range = 0.001:0.005:1;
  
  h1_range=0.001:0.005:0.3;
 
 
 for numh0 = 1:length(h0_range)
     
     h0 = h0_range(numh0);
     
     for numh1=1:length(h1_range)
         
         h1=h1_range(numh1);
         
         for numk=1:length(krange)
             
             k=krange(numk);
             
             vengkf(3) = h1;
             vengki(2) = coupJ*sin(k);
             vengki(3) = h0+coupJ*cos(k);
             
             engkf=h1;
             engki=sqrt((coupJ*sin(k))^2+(h0+coupJ*cos(k))^2);
             
             vnk(3)=vengkf(3)/engkf;
             vmk(2)=vengki(2)/engki;
             vmk(3)=vengki(3)/engki;
             
             engflq(numk)=(acos(cos(engkf)*cos(tau*engki)-dot(vnk,vmk)*sin(engkf)*sin(tau*engki)))/tau;
             %vnkf=vnk.*sin(engkf)*cos(engki*tau)+vmk.*sin(engki*tau)*cos(engkf)-cross(vnk,vmk).*sin(engkf)*sin(engki)
         end
         index=find(abs(engflq-min(engflq))<0.00000001);
         floquet_gap(numh0, numh1)=2*min(engflq);
         %kmin(numh0,numh1)=krange(index);
         kmin1 = krange(index);
         %engkivsh1(numh0,numh1)=sqrt((coupJ*sin(kmin1))^2+(h0+coupJ*cos(kmin1))^2);
     end
 end
 
MyFile=['Floquet_spect_PD2D_delta_N_' num2str(N) '_tau_' num2str(tau) '.mat']
save(MyFile,'N','h1','engflq','floquet_gap','tau','krange','h1_range', 'h0_range') 
    
hold on 
box on
figure(1)
mesh(krange,engflq)
%plot(krange,-engflq)
%plot(h0_range,floquet_gap)
end




