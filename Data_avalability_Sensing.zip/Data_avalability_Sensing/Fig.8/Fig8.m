function Fig_7
clc
clear



% 
% 

box on

hold on
title('(a)')
subplot(1,2,1)
load 'Floquet_spect_PD2D_square_N_2000_tau_1.mat'
surfl(h0_range,h1_range, floquet_gap)
shading interp
clear qf

subplot(1,2,2)
load 'avg_QFI_square_w_0.5_N_2000_tau_1_subl_04.mat'
surfl(h0_rrange,h1_rrange, qFisher)
shading interp
clear qf
title('(b)')