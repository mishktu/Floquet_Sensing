function Fig_2
clc
clear



% 
% 
subplot(2,2,1)
box on



load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.1_tau_0.2_subl_01.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
hold on 

load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.2_tau_0.2_subl_01.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.3_tau_0.2_subl_01.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

title('(a)')

leg = legend('h_1=0.1', 'h_1=0.2');


leg.ItemTokenSize = [30,18];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,2)
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.1_tau_0.2_subl_02.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
hold on 
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.2_tau_0.2_subl_02.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.3_tau_0.2_subl_02.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
leg = legend('h_1=0.1', 'h_1=0.2');


leg.ItemTokenSize = [30,18];
title('(b)')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,3)
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.1_tau_0.2_subl_010.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
hold on 
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.2_tau_0.2_subl_010.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.3_tau_0.2_subl_010.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
leg = legend('h_1=0.1', 'h_1=0.2');


leg.ItemTokenSize = [30,18];
title('(c)')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,4)
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.1_tau_0.2_subl_020.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher
hold on 
load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.2_tau_0.2_subl_020.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

load 'Gamma_QFI_delta_kick_h0_1_N_2000_h1_0.3_tau_0.2_subl_020.mat'
plot(time*tau,real(q_Fisher),'r','LineWidth',2)

clear q_Fisher

leg = legend('h_1=0.1', 'h_1=0.2');


leg.ItemTokenSize = [30,18];

title('(d)')

