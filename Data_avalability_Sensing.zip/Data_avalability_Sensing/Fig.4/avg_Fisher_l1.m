function avg_Fisher_l1
clc
clear

%********************* System Parameters **********************************
N=2000; subl = 4;   tau=0.2;  

h0_rrange = 0.01 : 0.01 : 1.2;

h1_rrange = 0.01:0.01:0.3;
%**************************************************************************


for numh0 = 1:length(h0_rrange)
    
    h0 = h0_rrange(numh0)
    
    for numh1 =1:length(h1_rrange)
        
        h1 = h1_rrange(numh1)
        disp([h0, h1])
        %
        File_Name= ['Gamma_QFI_delta_kick_h0_' num2str(h0) '_N_' num2str(N) '_h1_' num2str(h1) '_tau_' num2str(tau) '_subl_0' num2str(subl) '.mat'];
        %load(['Gamma_QFI_delta_kick_h0_' num2str(h0) '_N_' num2str(N) '_h1_' num2str(h1) '_tau_' num2str(tau) '_subl_0' num2str(subl) '.mat'])
        load(File_Name)
        %disp('loaded successefully')
        %disp( load(['Gamma_QFI_delta_kick_h0_' num2str(h0) '_N_' num2str(N) '_h1_' num2str(h1) '_tau_' num2str(tau) '_subl_0' num2str(subl) '.mat']))
        
        qf(numh0,numh1) =  real(Fisher_h0_h1);
    end
    
    %nqf(numh0,:) = qf;
end
mesh(h1_rrange,h0_rrange,qf)
  MyFile=['6New_avg_QFI_delta_kick_h1_' num2str(h1) '_tau_' num2str(tau) '_subl_' num2str(subl) '.mat']
  save(MyFile,'N','h1_rrange', 'h0_rrange', 'tau','subl','qf', 'dh1')
  
end
% 
% plot(N_range,avg)

% 
% 
%  q=q_range(numq);
%     disp(mat(q).name);
%     load(mat(q).name);
%     n=1800;
%     tau=0.2;
%     %new_t = n*tau;
%     %numq=subl;
%     avg(numq) = real(sum(q_Fisher(n:length(time))))/length(q_Fisher(n:length(time)));
%     %Prob_h1_datafqf=x;
%     %size(Prob_h1_datafqf)