function line_max_QFI

load  '3D_avg_QFI_delta_kick_N_2000_tau_0.2_subl_5.mat'

nh0_rrange = 0.01:0.01:1.1;
nh1_rrange = 0.01:0.01:0.4;

numh1 = 1:length(nh1_rrange);
numh0 = 1:length(nh0_rrange);

size(qf)
length(numh0)

nqf = qf(numh0,numh1);

[row, col] = find(nqf == max(nqf));

plot(nh1_rrange(col), nh0_rrange(row), 'bd');

%h1_range(row)
%h0_range(col)

hold on

nh1_rrange = abs(nh0_rrange -1)*tau;
plot(nh1_rrange,nh0_rrange, 'k')

% hold on 
% nn_h1_range = abs(h0_range -1)*tau;
% % plot(nn_h1_range,h0_range, 'k')

