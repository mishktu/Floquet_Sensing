function Fig_3
clc
clear



% 
% 
subplot(2,2,1)
box on



load '6New_avg_QFI_delta_kick_h1_0.3_tau_0.2_subl_1.mat'
surfl(h1_rrange,h0_rrange, qf)
shading interp
clear qf
title('(a)')

%******************************

hold on
title('(b)')
subplot(2,2,2)
load '6New_avg_QFI_delta_kick_h1_0.3_tau_0.2_subl_2.mat'
surfl(h1_rrange,h0_rrange, qf)
shading interp
clear qf

%******************************

hold on
title('(c)')
subplot(2,2,3)
shading interp
load '6New_avg_QFI_delta_kick_h1_0.3_tau_0.2_subl_4.mat'
surfl(h1_rrange,h0_rrange, qf)
shading interp



%**********************************

hold on
title('(a)')
subplot(2,2,4)
shading interp
load '6New_avg_QFI_delta_kick_h1_0.3_tau_0.2_subl_10.mat'
surfl(h1_rrange,h0_rrange, qf)
shading interp
