function Fig_6
clc
clear



% 
% 
subplot(2,2,1)
box on



load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.1_rho_4.mat'
plot(time*tau,real(dist_Bures),'r','LineWidth',2)

hold on 

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.1_rho_4.mat'
plot(time*tau,real(NMB_Fisher),'b','LineWidth',2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.1_rho_4.mat'
plot(time*tau,real(G_fisher_compt),'g','LineWidth',2)



load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.1_rho_4.mat'
plot(time*tau,real(G_fisher_Bell),'k','LineWidth',2)


title('(a)')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.2_rho_4.mat'
plot(time*tau,real(dist_Bures),'r','LineWidth',2)

hold on 

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.2_rho_4.mat'
plot(time*tau,real(NMB_Fisher),'b','LineWidth',2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.2_rho_4.mat'
plot(time*tau,real(G_fisher_compt),'g','LineWidth',2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.2_rho_4.mat'
plot(time*tau,real(G_fisher_Bell),'k','LineWidth',2)



title('(b)')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,3)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.3_rho_4.mat'
plot(time*tau,real(dist_Bures),'r','LineWidth',2)

hold on 

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.3_rho_4.mat'
plot(time*tau,real(NMB_Fisher),'b','LineWidth',2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.3_rho_4.mat'
plot(time*tau,real(G_fisher_compt),'g','LineWidth',2)



load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.3_rho_4.mat'
plot(time*tau,real(G_fisher_Bell),'k','LineWidth',2)

title('(c)')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

title('(d)')
subplot(2,2,4)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.4_rho_4.mat'
plot(time*tau,real(dist_Bures),'r','LineWidth',2)

hold on 

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.4_rho_4.mat'
plot(time*tau,real(NMB_Fisher),'b','LineWidth',2)

load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.4_rho_4.mat'
plot(time*tau,real(G_fisher_compt),'g','LineWidth',2)



load '14_u_1_v_0_QFI_TSDM_N_2000_h0_1_h1_0.4_rho_4.mat'
plot(time*tau,real(G_fisher_Bell),'k','LineWidth',2)

