function Fig_1
clc
clear



% 
% 
subplot(2,2,1)
box on
xlabel('n')
ylabel('M_z')


load 'Mz_large_n_PD2D_delta_h0_1_N_2000_statu_1_statv_0_tau_0.2_dh1_0.001_h1_0.1.mat'
plot(time*tau,Mz_n,'-r','LineWidth',2)

clear Mz_n

hold on 

load 'Mz_large_n_PD2D_delta_h0_1_N_2000_statu_1_statv_0_tau_0.2_dh1_0.001_h1_0.2.mat'
plot(time*tau,Mz_n,'--b','LineWidth',2)


hold on 

load 'Mz_large_n_PD2D_delta_h0_1_N_2000_statu_1_statv_0_tau_0.2_dh1_0.001_h1_0.3.mat'
 plot(time*tau,Mz_n,'.g','LineWidth',2)

hold on 

load 'Mz_large_n_PD2D_delta_h0_1_N_2000_statu_1_statv_0_tau_0.2_dh1_0.001_h1_0.4.mat'
 plot(time*tau,Mz_n,'-.k','LineWidth',2);
 
leg = {'h_1=0.1', 'h_1=0.2', 'h_1=0.3', 'h_1=0.4'};



leg.ItemTokenSize = [30,18];

%leg.NumColumns = 2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
subplot(2,2,2)
xlabel('h_1')
ylabel('M^{ss}_z')

load 'SSMz_large_n_PD2D_delta_h0_1_N_2000_statu_1_statv_0_tau_0.2_dh1_1e-05_nmax_5000.mat'
plot(h1_range,timeavgmz,'r','LineWidth',2)
title('(b)')
clear timeavgmz

hold on 
load 'SSMz_large_n_PD2D_delta_h0_0.4_N_2000_statu_1_statv_0_tau_0.2_dh1_1e-05_nmax_5000.mat'
plot(h1_range,timeavgmz,'b','LineWidth',2)

