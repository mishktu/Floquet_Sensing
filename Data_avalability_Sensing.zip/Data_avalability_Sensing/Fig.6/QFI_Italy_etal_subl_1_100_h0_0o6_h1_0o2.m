function QFI_Italy_etal_subl_29
% chekcing my code
clc
clear

global  N   krange coupJ h0 tau time
%%%%%%%%%

%********************* System Parameters **********************************
coupJ = 1; h0 =  0.6; h1 = 0.2 ; dh1=10^-3;

N=2000; 

mrange=0:N/2-1;  krange=pi*(2*mrange+1)/N;

tau=0.2;   time=4000:1:4400;

%**************************************************************************
subl_range = [1:1:20 24:4:100];

for numl = 1:length(subl_range)
    subl = subl_range(numl);
 for numt  = 1:length(time)
     t = time(numt);
%     
    %t = 4
    
    
%********************************* Making density matrix  at h1*************
    Gamma_h1=full(gmatrix(t,h1,subl));
    
    Gamma_h1dh1 = full(gmatrix(t,h1+dh1,subl));
    
    [V, eig_gamma]  = eig(Gamma_h1);
    
    eig_gamma = diag(imag(eig_gamma));
    
    derv_Gamma = (Gamma_h1dh1-Gamma_h1)/dh1;
    
    %d_mat = derv_Gamma*derv_Gamma;
    %derv_rho = (rho_h1dh1-rho_h1)/dh1;
    
 x_Fisher = 0;
%
for numi=1:2*subl
    for numj=1:2*subl 
        denom = 1 - eig_gamma(numi)*eig_gamma(numj);
         if(denom<= 10^-10)
              sum_Fisher=0;
         else
             denom1 = 1-(eig_gamma(numi)*eig_gamma(numj));
             sum_Fisher =  V(:,numi)'*derv_Gamma*V(:,numj)*V(:,numj)'*derv_Gamma*V(:,numi)/denom1;
          end
        x_Fisher = x_Fisher + sum_Fisher;
    end
end
% 
 q_Fisher(numt) = x_Fisher;

 end  
      
 L_Fisher = sum(q_Fisher)/length(time)

 
 
 MyFile=['3Gamma_QFI_delta_kick_h0_' num2str(h0) '_N_' num2str(N) '_h1_' num2str(h1) '_tau_' num2str(tau) '_subl_0' num2str(subl) '.mat']
  save(MyFile,'N','h0','h1','time','tau','subl', 'L_Fisher', 'dh1' )
 
end
 
%
% % *********** Plots ************
%
hold on 
plot(subl_range,L_Fisher, 'r')

%hold on 
%plot(time*tau,norm_dm_h1)

end

%trace(A*B)
%((1+ES(2))/2)

%size(C_opt{1})

%A=C_opt{3};
%B=C_opt{4};

%trace(A)
%1/2*(A*B+B*A)%-speye(2^(subl))












%**************************************************************************
%**************************************************************************
%*************************** Functions ************************************
%**************************************************************************
%**************************************************************************










%************** Evaluation of correlation matrix, Gamma *******************

function gam=gmatrix(t, h1, subl)

comat_maj=zeros(2*subl,2*subl);

for p=1:subl
    for q=1:subl
        
        out=delta_evolution(t,h1,p,q);
        
        
        Cij=out(1);
        Fij=out(2);
        
        
        
        %%%%%%%%%%%%%%
        %comat_maj==Gamma matrix.
        %this is the correlation matrix in terms of
        %majorana correlation function
        
        comat_maj(2 * p-1,2 * q-1) = double(eq(p,q)) + 2 * (1i) * imag(Cij + Fij);
        
        comat_maj(2 * p-1,2 * q)   = (1i) * double(eq(p,q)) - 2 * (1i) * real(Cij - Fij);
        
        comat_maj(2 * p,2 * q-1)   = (-1i) * double(eq(p,q)) + 2 * (1i) * real(Cij + Fij);
        
        comat_maj(2 * p,2 * q)     = double(eq(p,q)) + 2 * (1i) * imag(Cij-Fij);
        
    end
end
gam = comat_maj;
%gam=-1i*(comat_maj-eye(2*subl,2*subl));
end


%******************** Time evolution delta Kick **************************

function Output=delta_evolution(n,h1,p,q)

global N   krange coupJ h0  tau


for numk=1:length(krange)
    k=krange(numk);
    
     %theta=atan(coupJ*sin(k)/(h0 + coupJ*cos(k)));
    
    statv = 0; % cos(theta/2);
    
    statu = 1; %sin(theta/2);
    
    inst=zeros(2,1);
    
    inst(2)=statv;
    inst(1)=statu;
    
    vengkf = [0 0 h1]  ;
    
    vengki = [0 coupJ * sin(k) h0+coupJ*cos(k)];
    
    
    engkf=sqrt(h1^2);
    
    engki=sqrt((coupJ * sin(k))^2 + (h0 + coupJ*cos(k))^2);
    
    %vnk(2)=vengkf(2)/engkf;
    
    vnk =  vengkf/engkf;
    
    vmk = vengki/engki;
    
    %%%% exp(-i*Mk*(vnkf*sigma))=exp(-i*a*(vnk.sigma))8exp(-i*b*(vmk.sigma)), a=1, b=tau;
    %%%%%%
    
    Mk=cos(engkf) * cos(tau * engki) - dot(vnk,vmk) * sin(abs(engkf)) * sin(tau * abs(engki));
    
    engflq=acos(Mk)/tau;
    
    
    vnkf=(vnk.*(sin(abs(engkf))*cos(abs(engki)*tau))+vmk.*(sin(abs(engki)*tau)*cos(abs(engkf)))...
        -cross(vnk,vmk).*(sin(abs(engkf))*sin(tau*abs(engki))))/sin(abs(engflq)*tau);
    
    %%%%%% unitary evolution for floquet%%%
    
    untauk(1,1)=cos(engflq * tau * n) - (1i) * vnkf(3) * sin(abs(engflq) * n * tau);
    
    untauk(2,2)=cos(engflq * tau *n) + (1i) * vnkf(3) * sin(abs(engflq) * n * tau);
    
    untauk(1,2)=-(1i * vnkf(1) + vnkf(2)) * sin(abs(engflq) * n * tau);
    
    untauk(2,1)=-(1i * vnkf(1) - vnkf(2)) * sin(abs(engflq) * n * tau);
    
    finkntau=untauk*inst;
    
    u_kntau=finkntau(1,1);
    v_kntau=finkntau(2,1);
    
    alpha_pq(numk)=abs(u_kntau)^2*cos(k*(q-p)); %%% cpdcq
    
    beta_pq(numk)=conj(u_kntau)*v_kntau*sin(k*(p-q)); %%% cpdcqd;
    
end
Output=[2*sum(alpha_pq)/N  2*(1i)*sum(beta_pq)/N];
end


%**********************  Bures distance **********************************


function output_Bdst = Bures_dist(denst_m_B, denst_m_BDB,dh1)

dB=dh1;

drho_dB =  (denst_m_BDB - denst_m_B)/dB;

[eVec,eVal]= eig(denst_m_B);

eVal = diag(eVal);

dimr= length(denst_m_B);

B_dist = 0;

for numi=1:dimr
    for numj=1:dimr
        %size(eVec(:,numi))'
        B_dist = B_dist + abs((eVec(:,numi)'*drho_dB*eVec(:,numj)))^2/(eVal(numi)+eVal(numj));
    end
end

Bure_Dist  = abs(B_dist);

output_Bdst = Bure_Dist/2;

end





