
%load avg_Fisher_l1.m

load '3New_L_QFI_delta_kick_N_2000_tau_0.2_subl_100_h0_0.191_h1_0.161.mat'

%L_range = [1:1:20 24:4:100];
x =  L_range;
y = L_qf;

subplot(2,2,1)
 
 loglog(x,y,'rd');
 %fitting
 %xx = [10:20 24:4:100];
 %sy = 1:length(xx);
 %yy = L_qf(sy);
 [p,s] = polyfit(log(x),log(y),1)
 xx = [1:20 24:4:100];
 z = polyval(p,log(xx));
 hold on;
 loglog(xx,exp(z), 'r')

clear p z 


load '3New_L_QFI_delta_kick_N_2000_tau_0.2_subl_52_h0_0.83_h1_0.034.mat'

%L_range = [4:20 24:4:40];
x = L_range;
y = L_qf;

subplot(2,2,2)
 
 loglog(x,y,'rd');
 %axis([0 100 0 350])
 [p,s] = polyfit(log(x),log(y),1)
 xx = [1:20 24:4:100];
 z = polyval(p,log(xx));
 hold on;
 loglog(xx,exp(z), 'r')

clear p z 



% 
% 
% 

load '3New_L_QFI_delta_kick_N_2000_tau_0.2_subl_68_h0_0.161_h1_0.191.mat'

%L_range = [4:20 24:4:40];
x = L_range;
y = L_qf;

subplot(2,2,3)
 
 loglog(x,y,'rd');
 %axis([0 100 0 350])
 [p,s] = polyfit(log(x),log(y),1)
 xx = [1:20 24:4:100];
 z = polyval(p,log(xx));
 hold on;
 loglog(xx,exp(z), 'r')

clear p z 
% 
% 
% 
% 
% 
load '3New_L_QFI_delta_kick_N_2000_tau_0.2_subl_40_h0_0.6_h1_0.2.mat'

%L_range = [4:20 24:4:40];
x = L_range;
y = L_qf;

subplot(2,2,4)
 
 loglog(x,y,'rd');
 %axis([0 100 0 350])
 [p,s] = polyfit(log(x),log(y),1)
 xx = [1:20 24:4:100];
 z = polyval(p,log(xx));
 hold on;
 loglog(xx,exp(z), 'r')

clear p z 
% 

% yy=x.^4;
% p = polyfit(log(x),log(yy),1);
%  z = polyval(p,log(x));
%  hold on;
%  loglog(x,exp(z), 'b')
